var Profile = require("../models/profile");

var validUser = function(req, res, next) {
    Profile.findById(req.params.id, function(err, user){
       if (err)
        console.log(err);
        
     if (req.session.user._id === req.params.id ||  (user.lh == true && user.gaurdian.id == req.session.user._id)) {
        next(); //If session exists, proceed to page
    }
    else {
        var err = "Not your profile to change!";
        console.log(req.session.user);
        return next(err); //Error, trying to access unauthorized page!
    }
    
    });
   
};

module.exports = validUser;