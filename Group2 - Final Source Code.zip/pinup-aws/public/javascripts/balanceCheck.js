var positiveAmount = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/g;

var payoutAmount = document.querySelector('#payoutAmount');
var checkDisplay = document.querySelector('#checkAmount');

payoutAmount.onkeyup = function(){
    
    if(payoutAmount.value.match(positiveAmount)){
        checkDisplay.classList.remove("invalid");
        checkDisplay.classList.add("valid");
    }else{
        checkDisplay.classList.remove("valid");
        checkDisplay.classList.add("invalid");
    }
};